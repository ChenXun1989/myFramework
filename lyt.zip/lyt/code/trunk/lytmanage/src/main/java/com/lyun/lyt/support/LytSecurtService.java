package com.lyun.lyt.support;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthoritiesContainer;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.lyun.lyt.model.AdminModel;
import com.lyun.lyt.model.UserRoleModel;
import com.lyun.lyt.query.AdminQuery;
import com.lyun.lyt.service.AdminService;

@Component("userDetailsService")
public class LytSecurtService implements UserDetailsService {

	@Autowired
	private AdminService adminService;
	
	
	
	@Override
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		
		   AdminQuery query=new AdminQuery();
		   query.setNickname(username);
		   List<AdminModel> list=adminService.findAdvance(query);
		   AdminModel user=null;
		   if(CollectionUtils.isNotEmpty(list)){
			   user= list.get(0);
			   List<GrantedAuthority> authorities = buildUserAuthority(user);
			   
			    return buildUserForAuthentication(user, authorities);
		   }
		   
		   return null;
		   
		   
	}
	
	 /**
	   * 返回验证角色
	   * @param userRoles
	   * @return
	   */
	  private List<GrantedAuthority> buildUserAuthority(AdminModel user){
	    List<GrantedAuthority> result = new ArrayList<GrantedAuthority>();
	    Set<String> set=adminService.findRoleListByName(user.getNickname());
	    for(String userRole:set){
	    	result.add(new SimpleGrantedAuthority(userRole));
	      }
	    result.add(new SimpleGrantedAuthority("ROLE_USER"));   //基本角色
	    return result;
	  }
	   
	  /**
	   * 返回验证用户
	   * @param user
	   * @param authorities
	   * @return
	   */
	  private User buildUserForAuthentication(AdminModel user,List<GrantedAuthority> authorities){
	    return new User(user.getNickname(),user.getPasswd(),true,true,true,true,authorities);
	  }
	   
      

}
