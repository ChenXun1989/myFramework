package com.lyun.lyt.service;

import com.lyun.lyt.model.ResourceModel;
import com.lyun.lyt.query.ResourceQuery;

import java.util.List;


public interface ResourceService{

    //查询所有记录
	public List<ResourceModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public ResourceModel getById(long id);

	//删除
	public void del(ResourceModel resource);
	
	//新增
	public long insert(ResourceModel resource);
	
	//修改
	public long update(ResourceModel resource);
	
	//高级查询
	public List<ResourceModel> findAdvance(ResourceQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(ResourceQuery query);
	
	

}
