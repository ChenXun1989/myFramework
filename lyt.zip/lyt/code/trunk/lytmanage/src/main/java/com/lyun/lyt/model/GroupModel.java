package com.lyun.lyt.model;

import java.io.Serializable;
import java.util.Date;

public class GroupModel implements Serializable{
	
	 
	 	 	private int id;
	 	 	private String groupname;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setGroupname(String groupname){
			this.groupname=groupname;
		}
	
	
	    public String getGroupname(){
          return groupname;
	    }
	
	
	
		
}