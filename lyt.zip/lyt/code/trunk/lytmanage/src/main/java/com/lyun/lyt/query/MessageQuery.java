package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class MessageQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int id;
	 	 	private String from;
	 	 	private String to;
	 	 	private Date createTime;
	 	 	private String type;
	 	 	private String msg;
	 	 	private String uuid;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setFrom(String from){
			this.from=from;
		}
	
	
	    public String getFrom(){
          return from;
	    }
	
	
			public void setTo(String to){
			this.to=to;
		}
	
	
	    public String getTo(){
          return to;
	    }
	
	
			public void setCreateTime(Date createTime){
			this.createTime=createTime;
		}
	
	
	    public Date getCreateTime(){
          return createTime;
	    }
	
	
			public void setType(String type){
			this.type=type;
		}
	
	
	    public String getType(){
          return type;
	    }
	
	
			public void setMsg(String msg){
			this.msg=msg;
		}
	
	
	    public String getMsg(){
          return msg;
	    }
	
	
			public void setUuid(String uuid){
			this.uuid=uuid;
		}
	
	
	    public String getUuid(){
          return uuid;
	    }
	
	
	
		
}