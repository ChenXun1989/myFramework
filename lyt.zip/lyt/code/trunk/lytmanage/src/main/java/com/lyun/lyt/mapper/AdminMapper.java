package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.AdminModel;
import com.lyun.lyt.query.AdminQuery;

public interface  AdminMapper{
	

																																																																																																																				
	public String columns="id,passwd,nickname,phoneno";
	
	public String insert="passwd,nickname,phoneno";
																																																																																																												
	public String property="#{id},#{passwd},#{nickname},#{phoneno}";
	
	public String insertProperty="#{passwd},#{nickname},#{phoneno}";
																																																																																																																				
	public String update="passwd=#{passwd},nickname=#{nickname},phoneno=#{phoneno}";
	
	@Select("select "+columns+" FROM t_admin ")
	@ResultMap(value="com.lyun.lyt.mapper.AdminMapper.AdminModelMap")
	public List<AdminModel> findAll();
	
	@Select("select count(1) from t_admin ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_admin where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.AdminMapper.AdminModelMap")
	public AdminModel getById(long id);
	
	@Insert("insert into t_admin ("+insert+") values ("+insertProperty+")")
	public long insert(AdminModel admin);

	@Update("update t_admin set "+update+" where ID=#{id}")
	public long update(AdminModel admin); 
	
	@Delete("delete from t_admin where  ID=#{id} ")
	public void del(AdminModel admin);

	@SelectProvider(type=com.lyun.lyt.provider.AdminProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.AdminMapper.AdminModelMap")
	public List<AdminModel> fetchPageAdvance(AdminQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.AdminProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(AdminQuery query);
	
	@SelectProvider(type=com.lyun.lyt.provider.AdminProvider.class,method="findGroupRoleListByName")
	public List<String> findGroupRoleListByName(AdminQuery query);
	
	@SelectProvider(type=com.lyun.lyt.provider.AdminProvider.class,method="findRoleListByName")
	public List<String> findRoleListByName(AdminQuery query);
	
	
}