package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class GroupUserQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int id;
	 	 	private int userid;
	 	 	private int groupid;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setUserid(int userid){
			this.userid=userid;
		}
	
	
	    public int getUserid(){
          return userid;
	    }
	
	
			public void setGroupid(int groupid){
			this.groupid=groupid;
		}
	
	
	    public int getGroupid(){
          return groupid;
	    }
	
	
	
		
}