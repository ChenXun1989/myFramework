package com.lyun.lyt.service;

import com.lyun.lyt.model.RoleModel;
import com.lyun.lyt.query.RoleQuery;

import java.util.List;


public interface RoleService{

    //查询所有记录
	public List<RoleModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public RoleModel getById(long id);

	//删除
	public void del(RoleModel role);
	
	//新增
	public long insert(RoleModel role);
	
	//修改
	public long update(RoleModel role);
	
	//高级查询
	public List<RoleModel> findAdvance(RoleQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(RoleQuery query);
	
	

}
