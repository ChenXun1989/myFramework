package com.lyun.lyt.provider;

import com.lyun.lyt.query.RoleQuery;

import org.apache.commons.lang.StringUtils;


public class RoleProvider {

	public String columns="id,role,descpt,category";
	
	
	public String fetchPageAdvance(RoleQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_role where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getRole())){
						sql.append(" and role ='"+query.getRole()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getDescpt())){
						sql.append(" and descpt ='"+query.getDescpt()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getCategory())){
						sql.append(" and category ='"+query.getCategory()+"'");
					}
		         			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(RoleQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_role where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getRole())){
						sql.append(" and role ='"+query.getRole()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getDescpt())){
						sql.append(" and descpt ='"+query.getDescpt()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getCategory())){
						sql.append(" and category ='"+query.getCategory()+"'");
					}
		         			 		}
		
		
		return sql.toString();
	}
	
	
	

}
