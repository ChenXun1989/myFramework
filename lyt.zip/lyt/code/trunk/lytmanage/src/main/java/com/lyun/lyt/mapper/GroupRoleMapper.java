package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.GroupRoleModel;
import com.lyun.lyt.query.GroupRoleQuery;

public interface  GroupRoleMapper{
	

																																																																																																																				
	public String columns="id,groupid,roleid";
	
	public String insert="groupid,roleid";
																																																																																																												
	public String property="#{id},#{groupid},#{roleid}";
	
	public String insertProperty="#{groupid},#{roleid}";
																																																																																																																				
	public String update="groupid=#{groupid},roleid=#{roleid}";
	
	@Select("select "+columns+" FROM t_group_role ")
	@ResultMap(value="com.lyun.lyt.mapper.GroupRoleMapper.GroupRoleModelMap")
	public List<GroupRoleModel> findAll();
	
	@Select("select count(1) from t_group_role ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_group_role where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.GroupRoleMapper.GroupRoleModelMap")
	public GroupRoleModel getById(long id);
	
	@Insert("insert into t_group_role ("+insert+") values ("+insertProperty+")")
	public long insert(GroupRoleModel groupRole);

	@Update("update t_group_role set "+update+" where ID=#{id}")
	public long update(GroupRoleModel groupRole); 
	
	@Delete("delete from t_group_role where  ID=#{id} ")
	public void del(GroupRoleModel groupRole);

	@SelectProvider(type=com.lyun.lyt.provider.GroupRoleProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.GroupRoleMapper.GroupRoleModelMap")
	public List<GroupRoleModel> fetchPageAdvance(GroupRoleQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.GroupRoleProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(GroupRoleQuery query);
	
	
	
	
}