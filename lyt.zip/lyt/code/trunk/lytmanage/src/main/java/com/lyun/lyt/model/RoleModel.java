package com.lyun.lyt.model;

import java.io.Serializable;
import java.util.Date;

public class RoleModel implements Serializable{
	
	 
	 	 	private int id;
	 	 	private String role;
	 	 	private String descpt;
	 	 	private String category;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setRole(String role){
			this.role=role;
		}
	
	
	    public String getRole(){
          return role;
	    }
	
	
			public void setDescpt(String descpt){
			this.descpt=descpt;
		}
	
	
	    public String getDescpt(){
          return descpt;
	    }
	
	
			public void setCategory(String category){
			this.category=category;
		}
	
	
	    public String getCategory(){
          return category;
	    }
	
	
	
		
}