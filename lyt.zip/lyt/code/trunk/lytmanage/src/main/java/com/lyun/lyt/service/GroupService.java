package com.lyun.lyt.service;

import com.lyun.lyt.model.GroupModel;
import com.lyun.lyt.query.GroupQuery;

import java.util.List;


public interface GroupService{

    //查询所有记录
	public List<GroupModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public GroupModel getById(long id);

	//删除
	public void del(GroupModel group);
	
	//新增
	public long insert(GroupModel group);
	
	//修改
	public long update(GroupModel group);
	
	//高级查询
	public List<GroupModel> findAdvance(GroupQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(GroupQuery query);
	
	

}
