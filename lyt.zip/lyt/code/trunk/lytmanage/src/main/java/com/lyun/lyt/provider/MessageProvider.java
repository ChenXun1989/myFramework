package com.lyun.lyt.provider;

import com.lyun.lyt.query.MessageQuery;

import org.apache.commons.lang.StringUtils;


public class MessageProvider {

	public String columns="Id,from_,to_,create_time,type_,msg,uuid";
	
	
	public String fetchPageAdvance(MessageQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_message where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and Id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getFrom())){
						sql.append(" and from_ ='"+query.getFrom()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getTo())){
						sql.append(" and to_ ='"+query.getTo()+"'");
					}
		         			 		         			 		         if(!StringUtils.isBlank(query.getType())){
						sql.append(" and type_ ='"+query.getType()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getMsg())){
						sql.append(" and msg ='"+query.getMsg()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getUuid())){
						sql.append(" and uuid ='"+query.getUuid()+"'");
					}
		         			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(MessageQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_message where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and Id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getFrom())){
						sql.append(" and from_ ='"+query.getFrom()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getTo())){
						sql.append(" and to_ ='"+query.getTo()+"'");
					}
		         			 		         			 		         if(!StringUtils.isBlank(query.getType())){
						sql.append(" and type_ ='"+query.getType()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getMsg())){
						sql.append(" and msg ='"+query.getMsg()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getUuid())){
						sql.append(" and uuid ='"+query.getUuid()+"'");
					}
		         			 		}
		
		
		return sql.toString();
	}
	
	
	

}
