package com.lyun.lyt.controller;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lyun.lyt.support.BaseController;

@Controller
public class LytServiceLogController extends BaseController {
	
	@RequestMapping("login")
	public String login(ModelMap model ,String error){

		 /*
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext()
			    .getAuthentication()
			    .getPrincipal();
		System.out.println(userDetails.getUsername());
	   System.out.println(userDetails.getAuthorities());
	*/
		
		if(error!=null){
			switch (error) {
			case "1":error="用户名或密码错误";			
				break;
			default:
				break;
			}
			model.put("error", error);
		}
		
		return "login";
	}
	
	@RequestMapping("index")
	public String index(ModelMap model ,String error){
		model.put("error", error);

		 
			UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext()
				    .getAuthentication()
				    .getPrincipal();
			System.out.println(userDetails.getUsername());
		   System.out.println(userDetails.getAuthorities());
		
		
		
		return "index";
	}
	@RequestMapping("403")
	public String accessDenied(){
		
		return "403";
	}

}
