package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class RoleResourceQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int roleId;
	 	 	private int resourceId;
	 
			public void setRoleId(int roleId){
			this.roleId=roleId;
		}
	
	
	    public int getRoleId(){
          return roleId;
	    }
	
	
			public void setResourceId(int resourceId){
			this.resourceId=resourceId;
		}
	
	
	    public int getResourceId(){
          return resourceId;
	    }
	
	
	
		
}