package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class AdminQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int id;
	 	 	private String passwd;
	 	 	private String nickname;
	 	 	private String phoneno;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setPasswd(String passwd){
			this.passwd=passwd;
		}
	
	
	    public String getPasswd(){
          return passwd;
	    }
	
	
			public void setNickname(String nickname){
			this.nickname=nickname;
		}
	
	
	    public String getNickname(){
          return nickname;
	    }
	
	
			public void setPhoneno(String phoneno){
			this.phoneno=phoneno;
		}
	
	
	    public String getPhoneno(){
          return phoneno;
	    }
	
	
	
		
}