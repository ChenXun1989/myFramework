package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.UserRoleMapper;
import com.lyun.lyt.model.UserRoleModel;

import com.lyun.lyt.query.UserRoleQuery;
import com.lyun.lyt.service.UserRoleService;

    
@Service("userRoleService")
public class UserRoleServiceImpl implements UserRoleService{
	@Autowired
	private UserRoleMapper userRoleMapper;

    //查询所有记录 
	public List<UserRoleModel> findAll(){
		return userRoleMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return userRoleMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public UserRoleModel getById(long id){ 
		return userRoleMapper.getById(id);
	}
	
	
	//删除 
	public void del(UserRoleModel userRole){	  
		userRoleMapper.del(userRole);
	}
	
	//新增
	public long insert(UserRoleModel userRole){	
		return userRoleMapper.insert(userRole);	
	}
	
	//修改
	public long update(UserRoleModel userRole){
		return userRoleMapper.update(userRole);
	}
	
	//高级查询 
	@Override
	public List<UserRoleModel> findAdvance(UserRoleQuery query) {
		return userRoleMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(UserRoleQuery query) {
		return userRoleMapper.fetchPageAdvanceCount(query);
	}

	
	

}
