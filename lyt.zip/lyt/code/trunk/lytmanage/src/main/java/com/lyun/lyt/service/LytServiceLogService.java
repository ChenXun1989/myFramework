package com.lyun.lyt.service;

import com.lyun.lyt.model.LytServiceLogModel;
import com.lyun.lyt.query.LytServiceLogQuery;

import java.util.List;


public interface LytServiceLogService{

    //查询所有记录
	public List<LytServiceLogModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public LytServiceLogModel getById(long id);

	//删除
	public void del(LytServiceLogModel lytServicelog);
	
	//新增
	public long insert(LytServiceLogModel lytServicelog);
	
	//修改
	public long update(LytServiceLogModel lytServicelog);
	
	//高级查询
	public List<LytServiceLogModel> findAdvance(LytServiceLogQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(LytServiceLogQuery query);
	
	

}
