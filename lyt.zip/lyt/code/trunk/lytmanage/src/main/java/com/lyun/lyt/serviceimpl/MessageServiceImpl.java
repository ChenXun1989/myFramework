package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.MessageMapper;
import com.lyun.lyt.model.MessageModel;

import com.lyun.lyt.query.MessageQuery;
import com.lyun.lyt.service.MessageService;

    
@Service("messageService")
public class MessageServiceImpl implements MessageService{
	@Autowired
	private MessageMapper messageMapper;

    //查询所有记录 
	public List<MessageModel> findAll(){
		return messageMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return messageMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public MessageModel getById(long id){ 
		return messageMapper.getById(id);
	}
	
	
	//删除 
	public void del(MessageModel message){	  
		messageMapper.del(message);
	}
	
	//新增
	public long insert(MessageModel message){	
		return messageMapper.insert(message);	
	}
	
	//修改
	public long update(MessageModel message){
		return messageMapper.update(message);
	}
	
	//高级查询 
	@Override
	public List<MessageModel> findAdvance(MessageQuery query) {
		return messageMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(MessageQuery query) {
		return messageMapper.fetchPageAdvanceCount(query);
	}

	
	

}
