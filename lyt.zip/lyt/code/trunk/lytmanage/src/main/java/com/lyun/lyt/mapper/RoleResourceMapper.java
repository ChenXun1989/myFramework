package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.RoleModel;
import com.lyun.lyt.model.RoleResourceModel;
import com.lyun.lyt.query.RoleResourceQuery;

public interface  RoleResourceMapper{
	

																																																																																																																				
	public String columns="ROLE_ID,RESOURCE_ID";
	
	public String insert="E_ID,RESOURCE_ID";
																																																																																																												
	public String property="#{roleId},#{resourceId}";
	
	public String insertProperty="Id},#{resourceId}";
																																																																																																																				
	public String update="RESOURCE_ID=#{resourceId}";
	
	@Select("select "+columns+" FROM t_role_resource ")
	@ResultMap(value="com.lyun.lyt.mapper.RoleResourceMapper.RoleResourceModelMap")
	public List<RoleResourceModel> findAll();
	
	@Select("select count(1) from t_role_resource ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_role_resource where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.RoleResourceMapper.RoleResourceModelMap")
	public RoleResourceModel getById(long id);
	
	@Insert("insert into t_role_resource ("+insert+") values ("+insertProperty+")")
	public long insert(RoleResourceModel roleResource);

	@Update("update t_role_resource set "+update+" where ID=#{id}")
	public long update(RoleResourceModel roleResource); 
	
	@Delete("delete from t_role_resource where  ID=#{id} ")
	public void del(RoleResourceModel roleResource);

	@SelectProvider(type=com.lyun.lyt.provider.RoleResourceProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.RoleResourceMapper.RoleResourceModelMap")
	public List<RoleResourceModel> fetchPageAdvance(RoleResourceQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.RoleResourceProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(RoleResourceQuery query);
	
	@Select("select * from t_role  left join t_role_resource on t_role.id = t_role_resource.role_id where t_role_resource.resource_id =#{resourceId}")
	@ResultMap(value="com.lyun.lyt.mapper.RoleMapper.RoleModelMap")
	public List<RoleModel> findRoleListByResourceId(int resourceId);  
	
	
}