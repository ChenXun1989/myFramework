package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.ResourceModel;
import com.lyun.lyt.query.ResourceQuery;

public interface  ResourceMapper{
	

																																																																																																																				
	public String columns="ID,NAME,CONTENT,resource_type,resource_status,CREATE_DATE,CREATOR,PARENT_ID";
	
	public String insert="NAME,CONTENT,resource_type,resource_status,CREATE_DATE,CREATOR,PARENT_ID";
																																																																																																												
	public String property="#{id},#{name},#{content},#{resourceType},#{resourceStatus},#{createDate},#{creator},#{parentId}";
	
	public String insertProperty="#{name},#{content},#{resourceType},#{resourceStatus},#{createDate},#{creator},#{parentId}";
																																																																																																																				
	public String update="NAME=#{name},CONTENT=#{content},resource_type=#{resourceType},resource_status=#{resourceStatus},CREATE_DATE=#{createDate},CREATOR=#{creator},PARENT_ID=#{parentId}";
	
	@Select("select "+columns+" FROM t_resource ")
	@ResultMap(value="com.lyun.lyt.mapper.ResourceMapper.ResourceModelMap")
	public List<ResourceModel> findAll();
	
	@Select("select count(1) from t_resource ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_resource where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.ResourceMapper.ResourceModelMap")
	public ResourceModel getById(long id);
	
	@Insert("insert into t_resource ("+insert+") values ("+insertProperty+")")
	public long insert(ResourceModel resource);

	@Update("update t_resource set "+update+" where ID=#{id}")
	public long update(ResourceModel resource); 
	
	@Delete("delete from t_resource where  ID=#{id} ")
	public void del(ResourceModel resource);

	@SelectProvider(type=com.lyun.lyt.provider.ResourceProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.ResourceMapper.ResourceModelMap")
	public List<ResourceModel> fetchPageAdvance(ResourceQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.ResourceProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(ResourceQuery query);
	
	
	
	
}