package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.ResourceMapper;
import com.lyun.lyt.model.ResourceModel;

import com.lyun.lyt.query.ResourceQuery;
import com.lyun.lyt.service.ResourceService;

    
@Service("resourceService")
public class ResourceServiceImpl implements ResourceService{
	@Autowired
	private ResourceMapper resourceMapper;

    //查询所有记录 
	public List<ResourceModel> findAll(){
		return resourceMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return resourceMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public ResourceModel getById(long id){ 
		return resourceMapper.getById(id);
	}
	
	
	//删除 
	public void del(ResourceModel resource){	  
		resourceMapper.del(resource);
	}
	
	//新增
	public long insert(ResourceModel resource){	
		return resourceMapper.insert(resource);	
	}
	
	//修改
	public long update(ResourceModel resource){
		return resourceMapper.update(resource);
	}
	
	//高级查询 
	@Override
	public List<ResourceModel> findAdvance(ResourceQuery query) {
		return resourceMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(ResourceQuery query) {
		return resourceMapper.fetchPageAdvanceCount(query);
	}

	
	

}
