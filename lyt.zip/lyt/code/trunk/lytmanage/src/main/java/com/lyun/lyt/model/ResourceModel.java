package com.lyun.lyt.model;

import java.io.Serializable;
import java.util.Date;

public class ResourceModel implements Serializable{
	
	 
	 	 	private int id;
	 	 	private String name;
	 	 	private String content;
	 	 	private int resourceType;
	 	 	private int resourceStatus;
	 	 	private Date createDate;
	 	 	private String creator;
	 	 	private int parentId;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setName(String name){
			this.name=name;
		}
	
	
	    public String getName(){
          return name;
	    }
	
	
			public void setContent(String content){
			this.content=content;
		}
	
	
	    public String getContent(){
          return content;
	    }
	
	
			public void setResourceType(int resourceType){
			this.resourceType=resourceType;
		}
	
	
	    public int getResourceType(){
          return resourceType;
	    }
	
	
			public void setResourceStatus(int resourceStatus){
			this.resourceStatus=resourceStatus;
		}
	
	
	    public int getResourceStatus(){
          return resourceStatus;
	    }
	
	
			public void setCreateDate(Date createDate){
			this.createDate=createDate;
		}
	
	
	    public Date getCreateDate(){
          return createDate;
	    }
	
	
			public void setCreator(String creator){
			this.creator=creator;
		}
	
	
	    public String getCreator(){
          return creator;
	    }
	
	
			public void setParentId(int parentId){
			this.parentId=parentId;
		}
	
	
	    public int getParentId(){
          return parentId;
	    }
	
	
	
		
}