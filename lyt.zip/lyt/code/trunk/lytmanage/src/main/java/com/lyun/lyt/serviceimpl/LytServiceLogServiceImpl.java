package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.LytServiceLogMapper;
import com.lyun.lyt.model.LytServiceLogModel;

import com.lyun.lyt.query.LytServiceLogQuery;
import com.lyun.lyt.service.LytServiceLogService;

    
@Service("lytServicelogService")
public class LytServiceLogServiceImpl implements LytServiceLogService{
	@Autowired
	private LytServiceLogMapper lytServicelogMapper;

    //查询所有记录 
	public List<LytServiceLogModel> findAll(){
		return lytServicelogMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return lytServicelogMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public LytServiceLogModel getById(long id){ 
		return lytServicelogMapper.getById(id);
	}
	
	
	//删除 
	public void del(LytServiceLogModel lytServicelog){	  
		lytServicelogMapper.del(lytServicelog);
	}
	
	//新增
	public long insert(LytServiceLogModel lytServicelog){	
		return lytServicelogMapper.insert(lytServicelog);	
	}
	
	//修改
	public long update(LytServiceLogModel lytServicelog){
		return lytServicelogMapper.update(lytServicelog);
	}
	
	//高级查询 
	@Override
	public List<LytServiceLogModel> findAdvance(LytServiceLogQuery query) {
		return lytServicelogMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(LytServiceLogQuery query) {
		return lytServicelogMapper.fetchPageAdvanceCount(query);
	}

	
	

}
