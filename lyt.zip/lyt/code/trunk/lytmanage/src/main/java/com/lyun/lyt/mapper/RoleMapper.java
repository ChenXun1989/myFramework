package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.RoleModel;
import com.lyun.lyt.query.RoleQuery;

public interface  RoleMapper{
	

																																																																																																																				
	public String columns="id,role,descpt,category";
	
	public String insert="role,descpt,category";
																																																																																																												
	public String property="#{id},#{role},#{descpt},#{category}";
	
	public String insertProperty="#{role},#{descpt},#{category}";
																																																																																																																				
	public String update="role=#{role},descpt=#{descpt},category=#{category}";
	
	@Select("select "+columns+" FROM t_role ")
	@ResultMap(value="com.lyun.lyt.mapper.RoleMapper.RoleModelMap")
	public List<RoleModel> findAll();
	
	@Select("select count(1) from t_role ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_role where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.RoleMapper.RoleModelMap")
	public RoleModel getById(long id);
	
	@Insert("insert into t_role ("+insert+") values ("+insertProperty+")")
	public long insert(RoleModel role);

	@Update("update t_role set "+update+" where ID=#{id}")
	public long update(RoleModel role); 
	
	@Delete("delete from t_role where  ID=#{id} ")
	public void del(RoleModel role);

	@SelectProvider(type=com.lyun.lyt.provider.RoleProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.RoleMapper.RoleModelMap")
	public List<RoleModel> fetchPageAdvance(RoleQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.RoleProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(RoleQuery query);
	
	
	
	
}