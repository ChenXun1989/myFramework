package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.RoleMapper;
import com.lyun.lyt.model.RoleModel;

import com.lyun.lyt.query.RoleQuery;
import com.lyun.lyt.service.RoleService;

    
@Service("roleService")
public class RoleServiceImpl implements RoleService{
	@Autowired
	private RoleMapper roleMapper;

    //查询所有记录 
	public List<RoleModel> findAll(){
		return roleMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return roleMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public RoleModel getById(long id){ 
		return roleMapper.getById(id);
	}
	
	
	//删除 
	public void del(RoleModel role){	  
		roleMapper.del(role);
	}
	
	//新增
	public long insert(RoleModel role){	
		return roleMapper.insert(role);	
	}
	
	//修改
	public long update(RoleModel role){
		return roleMapper.update(role);
	}
	
	//高级查询 
	@Override
	public List<RoleModel> findAdvance(RoleQuery query) {
		return roleMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(RoleQuery query) {
		return roleMapper.fetchPageAdvanceCount(query);
	}

	
	

}
