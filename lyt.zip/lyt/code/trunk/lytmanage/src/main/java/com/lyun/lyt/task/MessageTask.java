package com.lyun.lyt.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.lyun.lyt.integration.HuanXinService;

/**
 * 定时任务
 * @author ChenXun
 *
 */
public class MessageTask {
	
	private Logger log=LoggerFactory.getLogger(MessageTask.class);
	
	@Autowired
	private HuanXinService huanXinService;
	public void job(){
		
		log.info("start job!!");
		huanXinService.saveMessage();
		
		
	}

}
