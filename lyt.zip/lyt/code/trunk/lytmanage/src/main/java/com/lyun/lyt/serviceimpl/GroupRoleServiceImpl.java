package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.GroupRoleMapper;
import com.lyun.lyt.model.GroupRoleModel;

import com.lyun.lyt.query.GroupRoleQuery;
import com.lyun.lyt.service.GroupRoleService;

    
@Service("groupRoleService")
public class GroupRoleServiceImpl implements GroupRoleService{
	@Autowired
	private GroupRoleMapper groupRoleMapper;

    //查询所有记录 
	public List<GroupRoleModel> findAll(){
		return groupRoleMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return groupRoleMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public GroupRoleModel getById(long id){ 
		return groupRoleMapper.getById(id);
	}
	
	
	//删除 
	public void del(GroupRoleModel groupRole){	  
		groupRoleMapper.del(groupRole);
	}
	
	//新增
	public long insert(GroupRoleModel groupRole){	
		return groupRoleMapper.insert(groupRole);	
	}
	
	//修改
	public long update(GroupRoleModel groupRole){
		return groupRoleMapper.update(groupRole);
	}
	
	//高级查询 
	@Override
	public List<GroupRoleModel> findAdvance(GroupRoleQuery query) {
		return groupRoleMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(GroupRoleQuery query) {
		return groupRoleMapper.fetchPageAdvanceCount(query);
	}

	
	

}
