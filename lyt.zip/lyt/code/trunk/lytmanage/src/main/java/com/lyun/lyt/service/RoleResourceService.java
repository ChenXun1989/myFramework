package com.lyun.lyt.service;

import com.lyun.lyt.model.RoleModel;
import com.lyun.lyt.model.RoleResourceModel;
import com.lyun.lyt.query.RoleResourceQuery;

import java.util.List;


public interface RoleResourceService{

    //查询所有记录
	public List<RoleResourceModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public RoleResourceModel getById(long id);

	//删除
	public void del(RoleResourceModel roleResource);
	
	//新增
	public long insert(RoleResourceModel roleResource);
	
	//修改
	public long update(RoleResourceModel roleResource);
	
	//高级查询
	public List<RoleResourceModel> findAdvance(RoleResourceQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(RoleResourceQuery query);
	
	public List<RoleModel> findRoleListByResourceId(int resourceId);
	
	

}
