package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.AdminMapper;
import com.lyun.lyt.model.AdminModel;
import com.lyun.lyt.query.AdminQuery;
import com.lyun.lyt.service.AdminService;

    
@Service("adminService")
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminMapper adminMapper;

    //查询所有记录 
	public List<AdminModel> findAll(){
		return adminMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return adminMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public AdminModel getById(long id){ 
		return adminMapper.getById(id);
	}
	
	
	//删除 
	public void del(AdminModel admin){	  
		adminMapper.del(admin);
	}
	
	//新增
	public long insert(AdminModel admin){	
		return adminMapper.insert(admin);	
	}
	
	//修改
	public long update(AdminModel admin){
		return adminMapper.update(admin);
	}
	
	//高级查询 
	@Override
	public List<AdminModel> findAdvance(AdminQuery query) {
		return adminMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(AdminQuery query) {
		return adminMapper.fetchPageAdvanceCount(query);
	}

	@Override
	public Set<String> findRoleListByName(String name) {
		AdminQuery query=new AdminQuery();
	 List<String> list1=adminMapper.findGroupRoleListByName(query);
	 List<String> list2=adminMapper.findRoleListByName(query);
	 Set<String> set=new HashSet<String>();
	 for(String s:list1){
		 set.add(s);
	 }
	 for(String s:list2){
		 set.add(s);
	 }
	 set.remove(null);
		return set;
	}

	
	

}
