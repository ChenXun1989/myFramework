package com.lyun.lyt.support;

import java.util.Collection;

import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;


public class LytVoter implements AccessDecisionVoter<Object> {

	@Override
	public boolean supports(ConfigAttribute attribute) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int vote(Authentication authentication, Object object,
			Collection<ConfigAttribute> attributes) {
	       for (ConfigAttribute attribute : attributes) {//可访问该页面的角色
	            for (GrantedAuthority authority : authentication.getAuthorities()) {//登录用户具备的角色
	                 if (attribute.getAttribute().equals(authority.getAuthority())) {//判断用户是否具有相应角色
	                	 
	                     return ACCESS_GRANTED;
	                 }
	                 System.out.print(attribute.getAttribute()+"用户的角色："+authority.getAuthority());
	            }
	        }
	       return ACCESS_DENIED;
	}

}
