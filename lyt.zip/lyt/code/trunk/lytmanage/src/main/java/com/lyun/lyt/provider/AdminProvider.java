package com.lyun.lyt.provider;

import com.lyun.lyt.query.AdminQuery;

import org.apache.commons.lang.StringUtils;


public class AdminProvider {

	public String columns="id,passwd,nickname,phoneno";
	
	
	public String fetchPageAdvance(AdminQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_admin where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getPasswd())){
						sql.append(" and passwd ='"+query.getPasswd()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getNickname())){
						sql.append(" and nickname ='"+query.getNickname()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getPhoneno())){
						sql.append(" and phoneno ='"+query.getPhoneno()+"'");
					}
		         			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(AdminQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_admin where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getPasswd())){
						sql.append(" and passwd ='"+query.getPasswd()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getNickname())){
						sql.append(" and nickname ='"+query.getNickname()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getPhoneno())){
						sql.append(" and phoneno ='"+query.getPhoneno()+"'");
					}
		         			 		}
		
		
		return sql.toString();
	}
	
	public String findGroupRoleListByName(AdminQuery query){
		StringBuffer sql=new StringBuffer("SELECT role.role  "+
           " FROM t_group AS g  " +
            "LEFT OUTER JOIN t_group_role AS grouprole ON (g.id = grouprole.groupid) "+ 
           " LEFT OUTER JOIN t_role AS role ON (role.id = grouprole.roleid)"+  
            "LEFT OUTER JOIN t_group_user AS groupuser on (g.id = groupuser.groupid) "+ 
           " LEFT OUTER JOIN t_admin ON (t_admin.id = groupuser.userid) ");
		if(query!=null){
			if(StringUtils.isNotBlank(query.getNickname()))
			sql.append(" WHERE t_admin.nickname ='"+query.getNickname()+"'");
		}
		

		return sql.toString();
	}
	public String findRoleListByName(AdminQuery query){
		StringBuffer sql=new StringBuffer("SELECT role.role as authorities  "+
           " FROM t_admin  " +
            " LEFT OUTER JOIN t_user_role AS userrole ON(t_admin.id = userrole.userid)  "+ 
           "  LEFT OUTER JOIN t_role AS role ON (userrole.roleid = role.id)");  
		if(query!=null){
			if(StringUtils.isNotBlank(query.getNickname()))
			sql.append(" WHERE t_admin.nickname ='"+query.getNickname()+"'");
		}
		

		return sql.toString();
	}
	
	

}
