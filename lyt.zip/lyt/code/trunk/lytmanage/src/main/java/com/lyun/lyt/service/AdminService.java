package com.lyun.lyt.service;

import com.lyun.lyt.model.AdminModel;
import com.lyun.lyt.query.AdminQuery;

import java.util.List;
import java.util.Set;


public interface AdminService{

    //查询所有记录
	public List<AdminModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public AdminModel getById(long id);

	//删除
	public void del(AdminModel admin);
	
	//新增
	public long insert(AdminModel admin);
	
	//修改
	public long update(AdminModel admin);
	
	//高级查询
	public List<AdminModel> findAdvance(AdminQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(AdminQuery query);
	
	public Set<String> findRoleListByName(String name);
		
	
	
	

}
