package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.MessageModel;
import com.lyun.lyt.query.MessageQuery;

public interface  MessageMapper{
	

																																																																																																																				
	public String columns="Id,from_,to_,create_time,type_,msg,uuid";
	
	public String insert="from_,to_,create_time,type_,msg,uuid";
																																																																																																												
	public String property="#{id},#{from},#{to},#{createTime},#{type},#{msg},#{uuid}";
	
	public String insertProperty="#{from},#{to},#{createTime},#{type},#{msg},#{uuid}";
																																																																																																																				
	public String update="from_=#{from},to_=#{to},create_time=#{createTime},type_=#{type},msg=#{msg},uuid=#{uuid}";
	
	@Select("select "+columns+" FROM t_message ")
	@ResultMap(value="com.lyun.lyt.mapper.MessageMapper.MessageModelMap")
	public List<MessageModel> findAll();
	
	@Select("select count(1) from t_message ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_message where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.MessageMapper.MessageModelMap")
	public MessageModel getById(long id);
	
	@Insert("insert into t_message ("+insert+") values ("+insertProperty+")")
	public long insert(MessageModel message);

	@Update("update t_message set "+update+" where ID=#{id}")
	public long update(MessageModel message); 
	
	@Delete("delete from t_message where  ID=#{id} ")
	public void del(MessageModel message);

	@SelectProvider(type=com.lyun.lyt.provider.MessageProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.MessageMapper.MessageModelMap")
	public List<MessageModel> fetchPageAdvance(MessageQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.MessageProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(MessageQuery query);
	
	
	
	
}