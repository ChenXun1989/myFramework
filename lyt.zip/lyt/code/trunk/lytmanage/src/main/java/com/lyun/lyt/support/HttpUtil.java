package com.lyun.lyt.support;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;

public class HttpUtil {

	private static HttpClient getInstance() throws KeyManagementException,
			NoSuchAlgorithmException {
		HttpClient client = new DefaultHttpClient();
		SSLContext ctx = SSLContext.getInstance("SSL");
		// SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(null, new TrustManager[] { trustManager }, null);
		ctx.init(null, new TrustManager[] { trustManager }, null);
		SSLSocketFactory ssf = new SSLSocketFactory(ctx);
		// 忽略掉HostName的比较，否则访问部分地址可能会报异常
		ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		ClientConnectionManager ccm = client.getConnectionManager();
		SchemeRegistry sr = ccm.getSchemeRegistry();
		sr.register(new Scheme("https", 443, ssf));
		client = new DefaultHttpClient(ccm, client.getParams());
		return client;
	}

	public static String exce(String url, List<NameValuePair> formparams,
			Header[] headers, boolean isGet) {

		return isGet ? get(url, headers) : post(url, formparams, headers);

	}

	private static String post(String url, List<NameValuePair> formparams,
			Header[] headers) {
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = HttpClients.createDefault();
		String inputLine = null;
		HttpEntity entity = null;
		// 创建httppost
		HttpPost httppost = new HttpPost(url);
		httppost.setHeaders(headers);
		UrlEncodedFormEntity uefEntity;
		try {
			uefEntity = new UrlEncodedFormEntity(formparams, "UTF-8");
			httppost.setEntity(uefEntity);
			System.out.println("executing request " + httppost.getURI());

			CloseableHttpResponse response = httpclient.execute(httppost);
			BufferedReader reader = null;
			InputStream in = null;
			try {
				entity = response.getEntity();

				StringBuffer contentBuffer = new StringBuffer();
				in = entity.getContent();
				reader = new BufferedReader(new InputStreamReader(in));

				while ((inputLine = reader.readLine()) != null) {
					contentBuffer.append(inputLine);
				}
				return contentBuffer.toString();
			} finally {
				reader.close();
				in.close();
				response.close();
			}

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 关闭连接,释放资源
			try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * 发送 get请求
	 * 
	 * @param headers
	 */
	private static String get(String url, Header[] headers) {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpEntity entity = null;
		String inputLine = null;
		try {
			// 创建httpget.
			HttpGet httpget = new HttpGet(url);
			httpget.setHeaders(headers);
			System.out.println("executing request " + httpget.getURI());
			// 执行get请求.
			CloseableHttpResponse response = httpclient.execute(httpget);
			InputStream in = null;
			BufferedReader reader = null;
			try {
				// 获取响应实体
				entity = response.getEntity();

				StringBuffer contentBuffer = new StringBuffer();
				in = entity.getContent();
				reader = new BufferedReader(new InputStreamReader(in));
				while ((inputLine = reader.readLine()) != null) {
					contentBuffer.append(inputLine);
				}
				return contentBuffer.toString();
			} finally {
				reader.close();
				in.close();
				response.close();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 关闭连接,释放资源
			try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	private static X509TrustManager trustManager = new X509TrustManager() {


		@Override
		public void checkClientTrusted(
				X509Certificate[] chain, String authType)
				throws java.security.cert.CertificateException {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void checkServerTrusted(
				X509Certificate[] chain, String authType)
				throws java.security.cert.CertificateException {
			// TODO Auto-generated method stub
			
		}

		@Override
		public X509Certificate[] getAcceptedIssuers() {
			// TODO Auto-generated method stub
			return null;
		}
	};


}
