package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class GroupQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int id;
	 	 	private String groupname;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setGroupname(String groupname){
			this.groupname=groupname;
		}
	
	
	    public String getGroupname(){
          return groupname;
	    }
	
	
	
		
}