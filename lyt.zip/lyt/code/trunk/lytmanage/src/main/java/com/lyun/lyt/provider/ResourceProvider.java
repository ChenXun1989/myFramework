package com.lyun.lyt.provider;

import com.lyun.lyt.query.ResourceQuery;

import org.apache.commons.lang.StringUtils;


public class ResourceProvider {

	public String columns="ID,NAME,CONTENT,resource_type,resource_status,CREATE_DATE,CREATOR,PARENT_ID";
	
	
	public String fetchPageAdvance(ResourceQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_resource where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and ID = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getName())){
						sql.append(" and NAME ='"+query.getName()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getContent())){
						sql.append(" and CONTENT ='"+query.getContent()+"'");
					}
		         			 		         if(query.getResourceType()>0){
						sql.append(" and resource_type = "+query.getResourceType());
					}
			     			 		         if(query.getResourceStatus()>0){
						sql.append(" and resource_status = "+query.getResourceStatus());
					}
			     			 		         			 		         if(!StringUtils.isBlank(query.getCreator())){
						sql.append(" and CREATOR ='"+query.getCreator()+"'");
					}
		         			 		         if(query.getParentId()>0){
						sql.append(" and PARENT_ID = "+query.getParentId());
					}
			     			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(ResourceQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_resource where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and ID = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getName())){
						sql.append(" and NAME ='"+query.getName()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getContent())){
						sql.append(" and CONTENT ='"+query.getContent()+"'");
					}
		         			 		         if(query.getResourceType()>0){
						sql.append(" and resource_type = "+query.getResourceType());
					}
			     			 		         if(query.getResourceStatus()>0){
						sql.append(" and resource_status = "+query.getResourceStatus());
					}
			     			 		         			 		         if(!StringUtils.isBlank(query.getCreator())){
						sql.append(" and CREATOR ='"+query.getCreator()+"'");
					}
		         			 		         if(query.getParentId()>0){
						sql.append(" and PARENT_ID = "+query.getParentId());
					}
			     			 		}
		
		
		return sql.toString();
	}
	
	
	

}
