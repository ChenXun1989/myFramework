package com.lyun.lyt.provider;

import com.lyun.lyt.query.GroupRoleQuery;

import org.apache.commons.lang.StringUtils;


public class GroupRoleProvider {

	public String columns="id,groupid,roleid";
	
	
	public String fetchPageAdvance(GroupRoleQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_group_role where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(query.getGroupid()>0){
						sql.append(" and groupid = "+query.getGroupid());
					}
			     			 		         if(query.getRoleid()>0){
						sql.append(" and roleid = "+query.getRoleid());
					}
			     			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(GroupRoleQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_group_role where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(query.getGroupid()>0){
						sql.append(" and groupid = "+query.getGroupid());
					}
			     			 		         if(query.getRoleid()>0){
						sql.append(" and roleid = "+query.getRoleid());
					}
			     			 		}
		
		
		return sql.toString();
	}
	
	
	

}
