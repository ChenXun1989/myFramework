package com.lyun.lyt.provider;

import com.lyun.lyt.query.GroupQuery;

import org.apache.commons.lang.StringUtils;


public class GroupProvider {

	public String columns="id,groupname";
	
	
	public String fetchPageAdvance(GroupQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_group where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getGroupname())){
						sql.append(" and groupname ='"+query.getGroupname()+"'");
					}
		         			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(GroupQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_group where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(!StringUtils.isBlank(query.getGroupname())){
						sql.append(" and groupname ='"+query.getGroupname()+"'");
					}
		         			 		}
		
		
		return sql.toString();
	}
	
	
	

}
