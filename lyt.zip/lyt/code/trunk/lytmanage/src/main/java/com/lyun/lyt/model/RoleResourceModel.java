package com.lyun.lyt.model;

import java.io.Serializable;
import java.util.Date;

public class RoleResourceModel implements Serializable{
	
	 
	 	 	private int roleId;
	 	 	private int resourceId;
	 
			public void setRoleId(int roleId){
			this.roleId=roleId;
		}
	
	
	    public int getRoleId(){
          return roleId;
	    }
	
	
			public void setResourceId(int resourceId){
			this.resourceId=resourceId;
		}
	
	
	    public int getResourceId(){
          return resourceId;
	    }
	
	
	
		
}