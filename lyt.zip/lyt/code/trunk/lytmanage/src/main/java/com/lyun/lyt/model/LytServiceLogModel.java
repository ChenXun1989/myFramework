package com.lyun.lyt.model;

import java.io.Serializable;
import java.util.Date;

public class LytServiceLogModel implements Serializable{
	
	 
	 	 	private int id;
	 	 	private Date startTime;
	 	 	private int servicestatus;
	 	 	private String serviceId;
	 	 	private String clientId;
	 	 	private int timeCount;
	 	 	private Date endTime;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setStartTime(Date startTime){
			this.startTime=startTime;
		}
	
	
	    public Date getStartTime(){
          return startTime;
	    }
	
	
			public void setServiceStatus(int servicestatus){
			this.servicestatus=servicestatus;
		}
	
	
	    public int getServiceStatus(){
          return servicestatus;
	    }
	
	
			public void setServiceId(String serviceId){
			this.serviceId=serviceId;
		}
	
	
	    public String getServiceId(){
          return serviceId;
	    }
	
	
			public void setClientId(String clientId){
			this.clientId=clientId;
		}
	
	
	    public String getClientId(){
          return clientId;
	    }
	
	
			public void setTimeCount(int timeCount){
			this.timeCount=timeCount;
		}
	
	
	    public int getTimeCount(){
          return timeCount;
	    }
	
	
			public void setEndTime(Date endTime){
			this.endTime=endTime;
		}
	
	
	    public Date getEndTime(){
          return endTime;
	    }
	
	
	
		
}