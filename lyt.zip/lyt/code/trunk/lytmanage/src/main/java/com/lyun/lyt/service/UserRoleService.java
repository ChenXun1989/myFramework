package com.lyun.lyt.service;

import com.lyun.lyt.model.UserRoleModel;
import com.lyun.lyt.query.UserRoleQuery;

import java.util.List;


public interface UserRoleService{

    //查询所有记录
	public List<UserRoleModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public UserRoleModel getById(long id);

	//删除
	public void del(UserRoleModel userRole);
	
	//新增
	public long insert(UserRoleModel userRole);
	
	//修改
	public long update(UserRoleModel userRole);
	
	//高级查询
	public List<UserRoleModel> findAdvance(UserRoleQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(UserRoleQuery query);
	
	

}
