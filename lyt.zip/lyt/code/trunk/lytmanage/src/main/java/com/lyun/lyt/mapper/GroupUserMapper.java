package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.GroupUserModel;
import com.lyun.lyt.query.GroupUserQuery;

public interface  GroupUserMapper{
	

																																																																																																																				
	public String columns="id,userid,groupid";
	
	public String insert="userid,groupid";
																																																																																																												
	public String property="#{id},#{userid},#{groupid}";
	
	public String insertProperty="#{userid},#{groupid}";
																																																																																																																				
	public String update="userid=#{userid},groupid=#{groupid}";
	
	@Select("select "+columns+" FROM t_group_user ")
	@ResultMap(value="com.lyun.lyt.mapper.GroupUserMapper.GroupUserModelMap")
	public List<GroupUserModel> findAll();
	
	@Select("select count(1) from t_group_user ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_group_user where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.GroupUserMapper.GroupUserModelMap")
	public GroupUserModel getById(long id);
	
	@Insert("insert into t_group_user ("+insert+") values ("+insertProperty+")")
	public long insert(GroupUserModel groupUser);

	@Update("update t_group_user set "+update+" where ID=#{id}")
	public long update(GroupUserModel groupUser); 
	
	@Delete("delete from t_group_user where  ID=#{id} ")
	public void del(GroupUserModel groupUser);

	@SelectProvider(type=com.lyun.lyt.provider.GroupUserProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.GroupUserMapper.GroupUserModelMap")
	public List<GroupUserModel> fetchPageAdvance(GroupUserQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.GroupUserProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(GroupUserQuery query);
	
	
	
	
}