package com.lyun.lyt.support;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.lyun.lyt.model.ResourceModel;
import com.lyun.lyt.model.RoleModel;
import com.lyun.lyt.model.RoleResourceModel;
import com.lyun.lyt.query.ResourceQuery;
import com.lyun.lyt.query.RoleResourceQuery;
import com.lyun.lyt.service.ResourceService;
import com.lyun.lyt.service.RoleResourceService;



public class LytFilterInvocationSecurityMetadataSource extends
		DefaultFilterInvocationSecurityMetadataSource {

	@Autowired
	private static ResourceService resourceService;
	@Autowired
	private static RoleResourceService roleResourceService;
	
	public LytFilterInvocationSecurityMetadataSource(
			LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap) {

		super(init());
		// TODO Auto-generated constructor stub
	}
	
	
	
	public static LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>>  init(){
		 LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap=new LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>>();
		 ResourceQuery query=new ResourceQuery();
		 query.setPageSize(-1);
		 query.setResourceType(1);   //1表示url
		List<ResourceModel>list= resourceService.findAdvance(query);	
		for(ResourceModel r:list){
			 Set<ConfigAttribute> allAttributes = new HashSet<ConfigAttribute>();
			 List<RoleModel> roles=roleResourceService.findRoleListByResourceId(r.getId());
			  for(RoleModel role:roles){
	                allAttributes.add(new SecurityConfig(role.getRole()));
	            }
			 RequestMatcher key=new AntPathRequestMatcher(r.getContent());
			 requestMap.put(key, allAttributes);
		}
	
		
		return requestMap;
	}  

	
}
