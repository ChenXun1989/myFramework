package com.lyun.lyt.support;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.io.output.StringBuilderWriter;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	    //1456532957316 1456533725948 1456534652334
		  StringBuffer contentBuffer = new StringBuffer();
					BufferedReader reader
					   = new BufferedReader(new FileReader("D://test.js"));
					String inputLine = null;
					while ((inputLine = reader.readLine()) != null) {
						contentBuffer.append(inputLine);
					}
					
					String s=contentBuffer.toString();
					s=s.replaceFirst("=", "\":");
					s="{\""+s+"}";			
					JSONObject json=JSONObject.fromObject(s);
				 //   System.out.println(s.substring(0,20));
					JSONArray arr=json.getJSONArray("shopServiceList");
					Iterator t=arr.iterator();
					while(t.hasNext()){
						JSONObject obj=JSONObject.fromObject(t.next());
						System.out.println(obj);
						
						
					}
					
					 
					
					

	}
	
	
	
	
	

}
