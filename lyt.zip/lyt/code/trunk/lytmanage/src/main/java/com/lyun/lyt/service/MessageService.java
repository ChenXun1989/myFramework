package com.lyun.lyt.service;

import com.lyun.lyt.model.MessageModel;
import com.lyun.lyt.query.MessageQuery;

import java.util.List;


public interface MessageService{

    //查询所有记录
	public List<MessageModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public MessageModel getById(long id);

	//删除
	public void del(MessageModel message);
	
	//新增
	public long insert(MessageModel message);
	
	//修改
	public long update(MessageModel message);
	
	//高级查询
	public List<MessageModel> findAdvance(MessageQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(MessageQuery query);
	
	

}
