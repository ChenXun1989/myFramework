package com.lyun.lyt.integration;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.springframework.beans.factory.annotation.Autowired;

import com.easemob.server.example.comm.Constants;
import com.easemob.server.example.comm.Roles;
import com.easemob.server.example.httpclient.vo.ClientSecretCredential;
import com.easemob.server.example.httpclient.vo.Credential;
import com.lyun.lyt.model.MessageModel;
import com.lyun.lyt.query.MessageQuery;
import com.lyun.lyt.service.MessageService;
import com.lyun.lyt.support.HttpUtil;





public class HuanXinService {
	
	public String getHuanXinUrl() {
		return HuanXinUrl;
	}


	public void setHuanXinUrl(String huanXinUrl) {
		HuanXinUrl = huanXinUrl;
	}

	private  String HuanXinUrl;
	@Autowired
	private MessageService messageService;
	
	// 通过app的client_id和client_secret来获取app管理员token
    private static Credential credential = new ClientSecretCredential(Constants.APP_CLIENT_ID,
            Constants.APP_CLIENT_SECRET, Roles.USER_ROLE_APPADMIN);
	
    
    public void saveMessage(){
    	
    
    
    	Date now=new Date();
    	MessageQuery query=new MessageQuery();
    	query.setPageSize(1);
    	List<MessageModel> last=	messageService.findAdvance(query);
    	//获取当前数据库最后一条消息
    	
    	//%3C  <   %3E  >
        String url=HuanXinUrl+"/chatmessages?ql=select+*+where+timestamp%3C"+now.getTime();
        
        if(last.size()>0){
        	url+="+and+timestamp%3E"+last.get(0).getCreateTime().getTime();
        }else {
        	SimpleDateFormat sdf=new SimpleDateFormat("YY-MM-DD");
        	
        	Date start;
			try {
				start = sdf.parse("2016-02-01");
				url+="+and+timestamp%3E"+start.getTime();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        }
		
		//{“Content-Type”:”application/json”,”Authorization”:”Bearer ${token}”}
		//https://a1.easemob.com/easemob-demo/chatdemoui/chatmessages?ql=select+*+where+timestamp>1403164734226
		//ql=select+*+where+timestamp>1403164734226  1403166586000
		
		
		
		Header[] header=new Header[2];
		header[0]=new BasicHeader("Content-Type", "application/json");
		header[1]=new BasicHeader("Authorization", "Bearer "+credential.getToken());
		String s=HttpUtil.exce(url, null, header,true);
	  //  url=URLEncoder.encode(url);
	//	String s=HttpExcuteUtil.getContent(url, null, null, true);
		JSONObject json=JSONObject.fromObject(s);	
		int count =json.getInt("count");
		System.out.println(count);
		String cursor=json.getString("cursor");
		System.out.println(cursor);
		List<MessageModel> list=	parseJson(json);
		if(StringUtils.isBlank(cursor)){
			for(MessageModel m:list){
				messageService.insert(m);
				System.out.println(m.getCreateTime().toLocaleString());
			}
		}
		
		
		while(StringUtils.isNotBlank(cursor)){
			url=HuanXinUrl+"/chatmessages?limit=100&cursor="+cursor;
			String str=HttpUtil.exce(url, null, header,true);
			JSONObject j=JSONObject.fromObject(str);	
			count=j.getInt("count");
			System.out.println(count);
			cursor=j.getString("cursor");
			System.out.println(cursor);
			List<MessageModel> messlist=	parseJson(j);
			for(MessageModel m:messlist){
				messageService.insert(m);
			}
			
		}
		

    }
    
    
    private List<MessageModel>  parseJson(JSONObject json){
    	
    	List<MessageModel> list =new ArrayList<MessageModel>();
		JSONArray arr=json.getJSONArray("entities");
		Iterator  i=arr.iterator();
		while (i.hasNext()) {
			MessageModel msgModle=new MessageModel();
			JSONObject obj=JSONObject.fromObject(i.next());
			String uuid=obj.getString("uuid");
			msgModle.setUuid(uuid);
			String from=obj.getString("from");   //获取来源
			msgModle.setFrom(from);
			String to=obj.getString("to");    //获取目标
			msgModle.setTo(to);
			String timestamp=obj.getString("timestamp");
			Date time=new Date(Long.parseLong(timestamp));
			msgModle.setCreateTime(time);   //发送时间
			
			JSONObject payload=obj.getJSONObject("payload");
			JSONArray bodies= payload.getJSONArray("bodies");
			Iterator t=bodies.iterator();
			while(t.hasNext()){
				JSONObject body=JSONObject.fromObject(t.next());  //消息体
				if("txt".equals(body.getString("type"))){  //文本消息
					String msg=body.getString("msg");
					msgModle.setMsg(msg);
					msgModle.setType("txt");
				}
				else if("img".equals(body.getString("type"))){
					String msg=body.getString("url");					
					msgModle.setMsg(msg.substring(HuanXinUrl.length()));
					msgModle.setType("img");
				}
				
			}
			list.add(msgModle);
			
		}
		return list;
    }
    
	public static void main(String[] args) throws IOException {
		
		System.out.println("hello");
	}

}
