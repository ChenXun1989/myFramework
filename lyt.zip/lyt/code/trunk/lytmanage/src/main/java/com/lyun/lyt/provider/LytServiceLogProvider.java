package com.lyun.lyt.provider;

import com.lyun.lyt.query.LytServiceLogQuery;

import org.apache.commons.lang.StringUtils;


public class LytServiceLogProvider {

	public String columns="Id,start_time,service_status,service_id,client_id,money_count,time_count,end_time";
	
	
	public String fetchPageAdvance(LytServiceLogQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_lyt_service_log where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and Id = "+query.getId());
					}
			     			 		         			 		         if(query.getServiceStatus()>0){
						sql.append(" and service_status = "+query.getServiceStatus());
					}
			     			 		         if(!StringUtils.isBlank(query.getServiceId())){
						sql.append(" and service_id ='"+query.getServiceId()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getClientId())){
						sql.append(" and client_id ='"+query.getClientId()+"'");
					}
		         			 		         if(query.getTimeCount()>0){
						sql.append(" and time_count = "+query.getTimeCount());
					}
			     			 		         			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(LytServiceLogQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_lyt_service_log where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and Id = "+query.getId());
					}
			     			 		         			 		         if(query.getServiceStatus()>0){
						sql.append(" and service_status = "+query.getServiceStatus());
					}
			     			 		         if(!StringUtils.isBlank(query.getServiceId())){
						sql.append(" and service_id ='"+query.getServiceId()+"'");
					}
		         			 		         if(!StringUtils.isBlank(query.getClientId())){
						sql.append(" and client_id ='"+query.getClientId()+"'");
					}
		         			 		         if(query.getTimeCount()>0){
						sql.append(" and time_count = "+query.getTimeCount());
					}
			     			 		         			 		}
		
		
		return sql.toString();
	}
	
	
	

}
