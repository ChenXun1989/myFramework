package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.RoleResourceMapper;
import com.lyun.lyt.model.RoleModel;
import com.lyun.lyt.model.RoleResourceModel;
import com.lyun.lyt.query.RoleResourceQuery;
import com.lyun.lyt.service.RoleResourceService;

    
@Service("roleResourceService")
public class RoleResourceServiceImpl implements RoleResourceService{
	@Autowired
	private RoleResourceMapper roleResourceMapper;

    //查询所有记录 
	public List<RoleResourceModel> findAll(){
		return roleResourceMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return roleResourceMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public RoleResourceModel getById(long id){ 
		return roleResourceMapper.getById(id);
	}
	
	
	//删除 
	public void del(RoleResourceModel roleResource){	  
		roleResourceMapper.del(roleResource);
	}
	
	//新增
	public long insert(RoleResourceModel roleResource){	
		return roleResourceMapper.insert(roleResource);	
	}
	
	//修改
	public long update(RoleResourceModel roleResource){
		return roleResourceMapper.update(roleResource);
	}
	
	//高级查询 
	@Override
	public List<RoleResourceModel> findAdvance(RoleResourceQuery query) {
		return roleResourceMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(RoleResourceQuery query) {
		return roleResourceMapper.fetchPageAdvanceCount(query);
	}

	@Override
	public List<RoleModel> findRoleListByResourceId(int resourceId) {
		return roleResourceMapper.findRoleListByResourceId(resourceId);
	}

	
	

}
