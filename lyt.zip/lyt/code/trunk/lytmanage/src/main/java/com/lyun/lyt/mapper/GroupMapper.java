package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.GroupModel;
import com.lyun.lyt.query.GroupQuery;

public interface  GroupMapper{
	

																																																																																																																				
	public String columns="id,groupname";
	
	public String insert="groupname";
																																																																																																												
	public String property="#{id},#{groupname}";
	
	public String insertProperty="#{groupname}";
																																																																																																																				
	public String update="groupname=#{groupname}";
	
	@Select("select "+columns+" FROM t_group ")
	@ResultMap(value="com.lyun.lyt.mapper.GroupMapper.GroupModelMap")
	public List<GroupModel> findAll();
	
	@Select("select count(1) from t_group ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_group where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.GroupMapper.GroupModelMap")
	public GroupModel getById(long id);
	
	@Insert("insert into t_group ("+insert+") values ("+insertProperty+")")
	public long insert(GroupModel group);

	@Update("update t_group set "+update+" where ID=#{id}")
	public long update(GroupModel group); 
	
	@Delete("delete from t_group where  ID=#{id} ")
	public void del(GroupModel group);

	@SelectProvider(type=com.lyun.lyt.provider.GroupProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.GroupMapper.GroupModelMap")
	public List<GroupModel> fetchPageAdvance(GroupQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.GroupProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(GroupQuery query);
	
	
	
	
}