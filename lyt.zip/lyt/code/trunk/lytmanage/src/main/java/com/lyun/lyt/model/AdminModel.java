package com.lyun.lyt.model;

import java.io.Serializable;
import java.util.Date;

public class AdminModel implements Serializable{
	
	 
	 	 	private int id;
	 	 	private String passwd;
	 	 	private String nickname;
	 	 	private String phoneno;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setPasswd(String passwd){
			this.passwd=passwd;
		}
	
	
	    public String getPasswd(){
          return passwd;
	    }
	
	
			public void setNickname(String nickname){
			this.nickname=nickname;
		}
	
	
	    public String getNickname(){
          return nickname;
	    }
	
	
			public void setPhoneno(String phoneno){
			this.phoneno=phoneno;
		}
	
	
	    public String getPhoneno(){
          return phoneno;
	    }
	
	
	
		
}