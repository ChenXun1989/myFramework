package com.lyun.lyt.support;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.lyun.lyt.model.ResourceModel;
import com.lyun.lyt.model.RoleModel;
import com.lyun.lyt.query.ResourceQuery;
import com.lyun.lyt.service.ResourceService;
import com.lyun.lyt.service.RoleResourceService;


@Configuration
@EnableWebSecurity
public class LytWebSecurityConfig extends WebSecurityConfigurerAdapter {

  
	@Autowired
	private  ResourceService resourceService;
	@Autowired
	private  RoleResourceService roleResourceService;
	@Autowired
	private UserDetailsService userDetailsService;
	
	
	 @Override  
	    public void configure(WebSecurity web) throws Exception {  
	        // 设置不拦截规则  
	        web.ignoring().antMatchers("/js","/css","/images");  
	  
	    }  
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		//配置资源权限
		
		 ResourceQuery query=new ResourceQuery();
		 query.setPageSize(-1);
		 query.setResourceType(1);   //1表示url
		List<ResourceModel>list= resourceService.findAdvance(query);	
		for(ResourceModel r:list){
			
			 List<RoleModel> roles=roleResourceService.findRoleListByResourceId(r.getId());
		    String[] arr=new String[roles.size()];
		    for(int i=0;i<roles.size();i++){
		    	arr[i]=roles.get(i).getRole().replaceAll("ROLE_", "");
		    } 
			 http.authorizeRequests().antMatchers(r.getContent()).hasAnyRole(arr);
			 
		}
		
		
		
		 // 设置拦截规则   
		http.authorizeRequests().antMatchers("/**").hasRole("USER");
  
        // 开启默认登录页面  
        // http.formLogin();  
  
        // 自定义登录页面  
        http.csrf().disable().formLogin().loginPage("/login.htm")  
                .failureUrl("/login.htm?error=1")  
                .loginProcessingUrl("/j_spring_security_check")  
                .usernameParameter("j_username")  
                .passwordParameter("j_password")
                .defaultSuccessUrl("/index.htm").permitAll();  
  
        // 自定义注销  
        http.logout().logoutUrl("/logout").logoutSuccessUrl("/login.htm?error=2")  
                .invalidateHttpSession(true);  
  
        // session管理 
        /*
        http.sessionManagement().sessionFixation().changeSessionId()  
                .maximumSessions(1).expiredUrl("/");  
                */
  
        // RemeberMe  
        http.rememberMe().key("lyt#FD637E6D9C0F1A5A67082AF56CE32485");  


	}
	
	
	 @Override  
	    protected void configure(AuthenticationManagerBuilder auth)  
	            throws Exception {  
	  
	        // 自定义UserDetailsService  
	        auth.userDetailsService(userDetailsService);
	        /*
	        .passwordEncoder(  
	                new Md5PasswordEncoder());  
	                */
	  
	    }  
	  
	   
	  
	

}
