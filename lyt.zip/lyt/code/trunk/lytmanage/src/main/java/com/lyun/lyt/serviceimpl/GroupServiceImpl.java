package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.GroupMapper;
import com.lyun.lyt.model.GroupModel;

import com.lyun.lyt.query.GroupQuery;
import com.lyun.lyt.service.GroupService;

    
@Service("groupService")
public class GroupServiceImpl implements GroupService{
	@Autowired
	private GroupMapper groupMapper;

    //查询所有记录 
	public List<GroupModel> findAll(){
		return groupMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return groupMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public GroupModel getById(long id){ 
		return groupMapper.getById(id);
	}
	
	
	//删除 
	public void del(GroupModel group){	  
		groupMapper.del(group);
	}
	
	//新增
	public long insert(GroupModel group){	
		return groupMapper.insert(group);	
	}
	
	//修改
	public long update(GroupModel group){
		return groupMapper.update(group);
	}
	
	//高级查询 
	@Override
	public List<GroupModel> findAdvance(GroupQuery query) {
		return groupMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(GroupQuery query) {
		return groupMapper.fetchPageAdvanceCount(query);
	}

	
	

}
