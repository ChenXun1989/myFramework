package com.lyun.lyt.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lyun.lyt.mapper.GroupUserMapper;
import com.lyun.lyt.model.GroupUserModel;

import com.lyun.lyt.query.GroupUserQuery;
import com.lyun.lyt.service.GroupUserService;

    
@Service("groupUserService")
public class GroupUserServiceImpl implements GroupUserService{
	@Autowired
	private GroupUserMapper groupUserMapper;

    //查询所有记录 
	public List<GroupUserModel> findAll(){
		return groupUserMapper.findAll();
	}
	
	//查询所有记录总数
	public int findAllCount(){
		return groupUserMapper.findAllCount();
	}
	
	
	
	//根据ID查询指定的数据(不分库)
	public GroupUserModel getById(long id){ 
		return groupUserMapper.getById(id);
	}
	
	
	//删除 
	public void del(GroupUserModel groupUser){	  
		groupUserMapper.del(groupUser);
	}
	
	//新增
	public long insert(GroupUserModel groupUser){	
		return groupUserMapper.insert(groupUser);	
	}
	
	//修改
	public long update(GroupUserModel groupUser){
		return groupUserMapper.update(groupUser);
	}
	
	//高级查询 
	@Override
	public List<GroupUserModel> findAdvance(GroupUserQuery query) {
		return groupUserMapper.fetchPageAdvance(query);
	}
	
	//高级查询总记录数
	@Override
	public int findAdvanceCount(GroupUserQuery query) {
		return groupUserMapper.fetchPageAdvanceCount(query);
	}

	
	

}
