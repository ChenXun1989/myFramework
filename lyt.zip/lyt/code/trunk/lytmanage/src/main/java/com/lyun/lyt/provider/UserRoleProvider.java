package com.lyun.lyt.provider;

import com.lyun.lyt.query.UserRoleQuery;

import org.apache.commons.lang.StringUtils;


public class UserRoleProvider {

	public String columns="id,userid,roleid";
	
	
	public String fetchPageAdvance(UserRoleQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_user_role where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(query.getUserid()>0){
						sql.append(" and userid = "+query.getUserid());
					}
			     			 		         if(query.getRoleid()>0){
						sql.append(" and roleid = "+query.getRoleid());
					}
			     			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(UserRoleQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_user_role where 1 = 1" );
		   if(query!=null){
		     		         if(query.getId()>0){
						sql.append(" and id = "+query.getId());
					}
			     			 		         if(query.getUserid()>0){
						sql.append(" and userid = "+query.getUserid());
					}
			     			 		         if(query.getRoleid()>0){
						sql.append(" and roleid = "+query.getRoleid());
					}
			     			 		}
		
		
		return sql.toString();
	}
	
	
	

}
