package com.lyun.lyt.support;

import java.io.IOException;

import org.apache.lucene.analysis.Tokenizer;
import org.wltea.analyzer.lucene.IKAnalyzer;
import org.wltea.analyzer.lucene.IKTokenizer;

public class LytAnalyzer extends IKAnalyzer {


}
