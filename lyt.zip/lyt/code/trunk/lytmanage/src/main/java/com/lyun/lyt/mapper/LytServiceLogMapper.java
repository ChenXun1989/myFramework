package com.lyun.lyt.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.lyun.lyt.model.LytServiceLogModel;
import com.lyun.lyt.query.LytServiceLogQuery;

public interface  LytServiceLogMapper{
	

																																																																																																																				
	public String columns="Id,start_time,service_status,service_id,client_id,money_count,time_count,end_time";
	
	public String insert="start_time,service_status,service_id,client_id,money_count,time_count,end_time";
																																																																																																												
	public String property="#{id},#{startTime},#{servicestatus},#{serviceId},#{clientId},#{timeCount},#{endTime}";
	
	public String insertProperty="#{startTime},#{servicestatus},#{serviceId},#{clientId},#{timeCount},#{endTime}";
																																																																																																																				
	public String update="start_time=#{startTime},service_status=#{servicestatus},service_id=#{serviceId},client_id=#{clientId},money_count=#{timeCount},time_count=#{endTime}";
	
	@Select("select "+columns+" FROM t_lyt_service_log ")
	@ResultMap(value="com.lyun.lyt.mapper.LytServiceLogMapper.LytServiceLogModelMap")
	public List<LytServiceLogModel> findAll();
	
	@Select("select count(1) from t_lyt_service_log ")
	public int findAllCount();
	
	@Select("select "+columns+" from t_lyt_service_log where ID=#{id}")
	@ResultMap(value="com.lyun.lyt.mapper.LytServiceLogMapper.LytServiceLogModelMap")
	public LytServiceLogModel getById(long id);
	
	@Insert("insert into t_lyt_service_log ("+insert+") values ("+insertProperty+")")
	public long insert(LytServiceLogModel lytServicelog);

	@Update("update t_lyt_service_log set "+update+" where ID=#{id}")
	public long update(LytServiceLogModel lytServicelog); 
	
	@Delete("delete from t_lyt_service_log where  ID=#{id} ")
	public void del(LytServiceLogModel lytServicelog);

	@SelectProvider(type=com.lyun.lyt.provider.LytServiceLogProvider.class,method="fetchPageAdvance")
	@ResultMap(value="com.lyun.lyt.mapper.LytServiceLogMapper.LytServiceLogModelMap")
	public List<LytServiceLogModel> fetchPageAdvance(LytServiceLogQuery query);  
	
	
	@SelectProvider(type=com.lyun.lyt.provider.LytServiceLogProvider.class,method="fetchPageAdvanceCount")
	public int fetchPageAdvanceCount(LytServiceLogQuery query);
	
	
	
	
}