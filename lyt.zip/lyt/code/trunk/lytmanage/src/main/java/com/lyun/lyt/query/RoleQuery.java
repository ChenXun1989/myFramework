package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class RoleQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int id;
	 	 	private String role;
	 	 	private String descpt;
	 	 	private String category;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setRole(String role){
			this.role=role;
		}
	
	
	    public String getRole(){
          return role;
	    }
	
	
			public void setDescpt(String descpt){
			this.descpt=descpt;
		}
	
	
	    public String getDescpt(){
          return descpt;
	    }
	
	
			public void setCategory(String category){
			this.category=category;
		}
	
	
	    public String getCategory(){
          return category;
	    }
	
	
	
		
}