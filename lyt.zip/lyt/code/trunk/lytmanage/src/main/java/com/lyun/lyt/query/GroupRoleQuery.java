package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class GroupRoleQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int id;
	 	 	private int groupid;
	 	 	private int roleid;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setGroupid(int groupid){
			this.groupid=groupid;
		}
	
	
	    public int getGroupid(){
          return groupid;
	    }
	
	
			public void setRoleid(int roleid){
			this.roleid=roleid;
		}
	
	
	    public int getRoleid(){
          return roleid;
	    }
	
	
	
		
}