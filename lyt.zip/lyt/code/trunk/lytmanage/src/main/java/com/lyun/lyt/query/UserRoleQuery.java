package com.lyun.lyt.query;

import java.io.Serializable;
import java.util.Date;

import com.lyun.lyt.support.QueryBase;

public class UserRoleQuery extends QueryBase implements Serializable {
	
	 
	 	 	private int id;
	 	 	private int userid;
	 	 	private int roleid;
	 
			public void setId(int id){
			this.id=id;
		}
	
	
	    public int getId(){
          return id;
	    }
	
	
			public void setUserid(int userid){
			this.userid=userid;
		}
	
	
	    public int getUserid(){
          return userid;
	    }
	
	
			public void setRoleid(int roleid){
			this.roleid=roleid;
		}
	
	
	    public int getRoleid(){
          return roleid;
	    }
	
	
	
		
}