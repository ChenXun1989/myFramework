package com.lyun.lyt.service;

import com.lyun.lyt.model.GroupRoleModel;
import com.lyun.lyt.query.GroupRoleQuery;

import java.util.List;


public interface GroupRoleService{

    //查询所有记录
	public List<GroupRoleModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public GroupRoleModel getById(long id);

	//删除
	public void del(GroupRoleModel groupRole);
	
	//新增
	public long insert(GroupRoleModel groupRole);
	
	//修改
	public long update(GroupRoleModel groupRole);
	
	//高级查询
	public List<GroupRoleModel> findAdvance(GroupRoleQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(GroupRoleQuery query);
	
	

}
