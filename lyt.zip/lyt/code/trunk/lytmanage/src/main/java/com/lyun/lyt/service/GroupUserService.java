package com.lyun.lyt.service;

import com.lyun.lyt.model.GroupUserModel;
import com.lyun.lyt.query.GroupUserQuery;

import java.util.List;


public interface GroupUserService{

    //查询所有记录
	public List<GroupUserModel> findAll();
	
	//查询所有记录总数
	public int findAllCount();
	
	//根据ID查询指定的数据(不分库)
	public GroupUserModel getById(long id);

	//删除
	public void del(GroupUserModel groupUser);
	
	//新增
	public long insert(GroupUserModel groupUser);
	
	//修改
	public long update(GroupUserModel groupUser);
	
	//高级查询
	public List<GroupUserModel> findAdvance(GroupUserQuery query);
	
	//高级查询总记录数
	public int findAdvanceCount(GroupUserQuery query);
	
	

}
