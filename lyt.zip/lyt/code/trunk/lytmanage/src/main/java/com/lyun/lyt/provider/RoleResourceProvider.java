package com.lyun.lyt.provider;

import com.lyun.lyt.query.RoleResourceQuery;

import org.apache.commons.lang.StringUtils;


public class RoleResourceProvider {

	public String columns="ROLE_ID,RESOURCE_ID";
	
	
	public String fetchPageAdvance(RoleResourceQuery query){  
		StringBuffer sql=new StringBuffer("select "+columns+" from t_role_resource where 1 = 1" );
		   if(query!=null){
		     		         if(query.getRoleId()>0){
						sql.append(" and ROLE_ID = "+query.getRoleId());
					}
			     			 		         if(query.getResourceId()>0){
						sql.append(" and RESOURCE_ID = "+query.getResourceId());
					}
			     			 		}
		
		

	
		sql.append(" order by ID desc " );
		if(query.getPageSize()>0){
		sql.append(" limit "+query.getStartRow()+","+query.getEndRow() );
		}
		

		return sql.toString();
	}
	
	public String fetchPageAdvanceCount(RoleResourceQuery query){
		StringBuffer sql=new StringBuffer("select count(1) from t_role_resource where 1 = 1" );
		   if(query!=null){
		     		         if(query.getRoleId()>0){
						sql.append(" and ROLE_ID = "+query.getRoleId());
					}
			     			 		         if(query.getResourceId()>0){
						sql.append(" and RESOURCE_ID = "+query.getResourceId());
					}
			     			 		}
		
		
		return sql.toString();
	}
	
	
	

}
