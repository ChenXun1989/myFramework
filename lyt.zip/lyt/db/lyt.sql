﻿# Host: localhost  (Version: 5.6.24)
# Date: 2016-03-10 16:34:12
# Generator: MySQL-Front 5.3  (Build 4.118)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "t_admin"
#

CREATE TABLE `t_admin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `passwd` varchar(12) NOT NULL DEFAULT '' COMMENT '用户密码',
  `nickname` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名字',
  `phoneno` varchar(32) NOT NULL DEFAULT '' COMMENT '电话号码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Structure for table "t_group"
#

CREATE TABLE `t_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Structure for table "t_group_user"
#

CREATE TABLE `t_group_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) unsigned NOT NULL,
  `groupid` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `groupid` (`groupid`),
  CONSTRAINT `t_group_user_ibfk_2` FOREIGN KEY (`groupid`) REFERENCES `t_group` (`id`),
  CONSTRAINT `t_group_user_ibfk_3` FOREIGN KEY (`userid`) REFERENCES `t_admin` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Structure for table "t_lyt_service_log"
#

CREATE TABLE `t_lyt_service_log` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '开始时间',
  `service_status` int(11) NOT NULL DEFAULT '0' COMMENT '0表示服务中 1表示服务正常结束 2表示客户取消 3表示响应超时，4表示翻译取消',
  `service_id` varchar(255) NOT NULL DEFAULT '' COMMENT '服务者id',
  `client_id` varchar(255) NOT NULL DEFAULT '' COMMENT '客户ID',
  `money_count` float NOT NULL DEFAULT '0' COMMENT '总金额 两位小数',
  `time_count` int(11) NOT NULL DEFAULT '0' COMMENT '总时长',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '结束时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='律译通服务日志';

#
# Structure for table "t_resource"
#

CREATE TABLE `t_resource` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) DEFAULT NULL,
  `CONTENT` varchar(1000) DEFAULT NULL,
  `resource_type` int(11) DEFAULT '1' COMMENT '1:url Address, 2:menu',
  `resource_status` int(11) DEFAULT '0' COMMENT '0正常',
  `CREATE_DATE` datetime DEFAULT NULL,
  `CREATOR` varchar(60) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL COMMENT '父级id',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Structure for table "t_role"
#

CREATE TABLE `t_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(40) NOT NULL DEFAULT '',
  `descpt` varchar(40) NOT NULL DEFAULT '' COMMENT '角色描述',
  `category` varchar(40) NOT NULL DEFAULT '' COMMENT '分类',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Structure for table "t_group_role"
#

CREATE TABLE `t_group_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` bigint(20) unsigned NOT NULL,
  `roleid` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupid2` (`groupid`,`roleid`),
  KEY `roleid` (`roleid`),
  CONSTRAINT `t_group_role_ibfk_1` FOREIGN KEY (`groupid`) REFERENCES `t_group` (`id`),
  CONSTRAINT `t_group_role_ibfk_2` FOREIGN KEY (`roleid`) REFERENCES `t_role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Structure for table "t_role_resource"
#

CREATE TABLE `t_role_resource` (
  `ROLE_ID` int(11) DEFAULT NULL,
  `RESOURCE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "t_user_role"
#

CREATE TABLE `t_user_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) unsigned NOT NULL,
  `roleid` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `roleid` (`roleid`),
  CONSTRAINT `t_user_role_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `t_admin` (`id`),
  CONSTRAINT `t_user_role_ibfk_2` FOREIGN KEY (`roleid`) REFERENCES `t_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
