﻿# Host: localhost  (Version: 5.6.24)
# Date: 2016-03-11 09:26:00
# Generator: MySQL-Front 5.3  (Build 4.118)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "t_message"
#

CREATE TABLE `t_message` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `from_` varchar(255) DEFAULT NULL COMMENT '发送者',
  `to_` varchar(255) DEFAULT NULL COMMENT '接收者',
  `create_time` datetime DEFAULT NULL COMMENT '时间',
  `type_` varchar(255) DEFAULT NULL COMMENT '类型',
  `msg` varchar(255) DEFAULT NULL COMMENT '消息体',
  `uuid` varchar(255) DEFAULT NULL COMMENT '编号',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='环信聊天记录';
